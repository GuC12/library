// ===== ДАННЫЕ КНИГ =====
const books = [
  {
    id: 1,
    title: "Чистый код",
    author: "Роберт Мартин",
    category: "Основы",
    price: 0,
    cover: "",
    spine: "#69553D",
    summary: "Как писать код, который легко читать и поддерживать: именование, функции, форматирование.",
    pages: [
      { kicker: "Глава 1", title: "Имена имеют значение", text: "Хорошее имя требует времени, но экономит его в будущем. Имя переменной, функции или класса должно отвечать на главный вопрос: зачем этот объект существует?" },
      { kicker: "Чистый код", title: "Говорите точнее", text: "Избегайте имён, которые ничего не объясняют. Чем меньше читателю приходится догадываться о смысле кода, тем спокойнее он может работать с системой." },
      { kicker: "Глава 2", title: "Функции должны быть маленькими", text: "Функция выполняет одну задачу, делает её хорошо и не пытается заодно решить ещё пять проблем. Маленькие функции проще читать, проверять и менять." },
      { kicker: "Практика", title: "Код как хороший текст", text: "Сложность не исчезает сама. Но ясная структура, точные названия и последовательный стиль делают её видимой — а значит, управляемой." }
    ]
  },
  {
    id: 2,
    title: "Паттерны проектирования",
    author: "GoF",
    category: "Архитектура",
    price: 0,
    cover: "",
    spine: "#8C704B",
    summary: "23 классических паттерна проектирования с примерами применения.",
    pages: [
      { kicker: "Введение", title: "Повторяемые решения", text: "Паттерн — это не готовый фрагмент кода, а проверенная схема взаимодействия объектов. Она помогает назвать проблему и обсудить решение на общем языке." },
      { kicker: "Наблюдатель", title: "Объекты и события", text: "Когда один объект меняется, другие могут узнать об этом через понятный контракт. Так система остаётся гибкой и не связывает каждый компонент с каждым." },
      { kicker: "Фабрика", title: "Создание без лишних деталей", text: "Пусть клиентский код знает, что ему нужен продукт, но не обязан знать все детали его создания. Это снижает связность и упрощает расширение." },
      { kicker: "Практика", title: "Не применяйте паттерны вслепую", text: "Паттерн полезен, когда он убирает конкретную сложность. Если решение становится тяжелее самой задачи, это сигнал остановиться и выбрать простоту." }
    ]
  },
  {
    id: 3,
    title: "Совершенный алгоритм",
    author: "Р. Седжвик",
    category: "Алгоритмы",
    price: 4200,
    cover: "",
    spine: "#3E2F1C",
    summary: "Базовые структуры данных и алгоритмы с разбором сложности.",
    pages: [
      { kicker: "Основы", title: "Думайте о данных", text: "Алгоритм начинается не с цикла, а с вопроса: как устроены данные? Правильная структура часто делает решение короче и быстрее, чем оптимизация отдельных строк." },
      { kicker: "Оценка", title: "Сложность — это разговор", text: "Оценка порядка роста помогает заранее увидеть границы решения. Она не заменяет измерения, но показывает, где система начнёт испытывать давление." },
      { kicker: "Поиск", title: "От полного перебора к идее", text: "Иногда самый понятный способ — перебрать все варианты. Но если данные упорядочены или повторяются, алгоритм может использовать эту информацию и не делать лишнюю работу." },
      { kicker: "Практика", title: "Скорость и ясность", text: "Лучший алгоритм — не тот, что выглядит самым хитрым. Это решение, которое достаточно быстро работает и остаётся понятным следующему человеку." }
    ]
  }
];

let cart = JSON.parse(localStorage.getItem("cart") || "[]");
let bookmarks = JSON.parse(localStorage.getItem("bookmarks") || "{}");
let activeFilter = "Все";
let searchQuery = "";
let currentBookId = null;
let currentPageIndex = 0;
let isFlipping = false;

const bookGrid = document.getElementById("bookGrid");
const emptyState = document.getElementById("emptyState");
const readerModal = document.getElementById("readerModal");

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

function coverMarkup(book, reader = false) {
  const title = escapeHTML(book.title);
  const author = escapeHTML(book.author);
  const category = escapeHTML(book.category);
  if (reader) {
    return `
      <div class="reader-cover-content">
        <small>${category}</small>
        <strong>${title}</strong>
        <small>${author}</small>
      </div>
    `;
  }
  return `
    ${book.cover ? `<img src="${escapeHTML(book.cover)}" alt="${title}">` : ""}
    <div class="cover-content">
      <span class="cover-category">${category}</span>
      <strong class="cover-title">${title}</strong>
      <span class="cover-author">${author}</span>
    </div>
  `;
}

// ===== ФИЛЬТРЫ ПО КАТЕГОРИЯМ =====
function renderFilters() {
  const categories = ["Все", ...new Set(books.map((book) => book.category))];
  const wrap = document.getElementById("filters");
  if (!wrap) return;
  wrap.innerHTML = "";
  categories.forEach((category) => {
    const button = document.createElement("button");
    button.className = "filter-btn" + (category === activeFilter ? " active" : "");
    button.textContent = category;
    button.addEventListener("click", () => {
      activeFilter = category;
      renderFilters();
      renderBooks();
    });
    wrap.appendChild(button);
  });
}

// ===== КАТАЛОГ =====
function renderBooks() {
  const filtered = books.filter((book) =>
    (activeFilter === "Все" || book.category === activeFilter) &&
    (book.title.toLowerCase().includes(searchQuery) || book.author.toLowerCase().includes(searchQuery))
  );

  bookGrid.innerHTML = "";
  emptyState.classList.toggle("hidden", filtered.length > 0);

  filtered.forEach((book) => {
    const card = document.createElement("article");
    card.className = "book-card";
    card.innerHTML = `
      <div class="book-cover" style="--spine-color:${book.spine}" role="img" aria-label="Обложка книги «${escapeHTML(book.title)}»">
        ${coverMarkup(book)}
      </div>
      <div class="book-name">${escapeHTML(book.title)}</div>
      <div class="book-author">${escapeHTML(book.author)}</div>
      <div class="book-price">${book.price === 0 ? "Бесплатно" : book.price + " ₸"}</div>
      <div class="card-buttons">
        <button class="green-btn" onclick="openReader(${book.id})">${book.price === 0 ? "Читать бесплатно" : "Открыть книгу"}</button>
        ${book.price > 0 ? `<button class="outline-btn" onclick="addToCart(${book.id})">В корзину</button>` : ""}
      </div>
    `;
    bookGrid.appendChild(card);
  });
}

document.getElementById("searchInput").addEventListener("input", (event) => {
  searchQuery = event.target.value.toLowerCase().trim();
  renderBooks();
});

// ===== ЧТЕНИЕ =====
function getCurrentBook() {
  return books.find((book) => book.id === currentBookId);
}

function setReaderTab(tab) {
  const isSummary = tab === "summary";
  document.querySelectorAll(".tab-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === tab);
  });
  document.getElementById("summaryText").classList.toggle("hidden", !isSummary);
  document.getElementById("fullText").classList.toggle("hidden", isSummary);
  document.getElementById("readerProgress").textContent = isSummary
    ? "Краткое содержание"
    : document.getElementById("pageCount").textContent + " страниц";
  if (!isSummary) renderPages();
  updateReaderProgress();
}

function openReader(id) {
  const book = books.find((item) => item.id === id);
  if (!book) return;

  currentBookId = id;
  currentPageIndex = 0;
  isFlipping = false;
  document.getElementById("readerToolbarTitle").textContent = book.title;
  document.getElementById("summaryText").innerHTML = `
    <div class="summary-layout">
      <div class="reader-cover" style="border-left-color:${book.spine}">
        ${coverMarkup(book, true)}
      </div>
      <div>
        <h2 class="reader-title" id="readerTitle">${escapeHTML(book.title)}</h2>
        <p class="reader-author">${escapeHTML(book.author)} · ${escapeHTML(book.category)}</p>
        <span class="summary-label">О книге</span>
        <p class="summary-copy">${escapeHTML(book.summary)}</p>
        <button class="green-btn start-reading" id="startReading" type="button">Начать чтение</button>
      </div>
    </div>
  `;
  document.getElementById("startReading").addEventListener("click", () => setReaderTab("full"));
  document.querySelectorAll(".tab-btn").forEach((button) => button.classList.remove("active"));
  document.querySelector('[data-tab="summary"]').classList.add("active");
  document.getElementById("summaryText").classList.remove("hidden");
  document.getElementById("fullText").classList.add("hidden");
  document.getElementById("bookmarkBtn").textContent = bookmarks[id] ? "✓ Место сохранено" : "♡ Сохранить место";
  renderPages();
  updateReaderProgress();
  showModal("readerModal");
}

function pageMarkup(page, number) {
  if (!page) {
    return `<span class="page-number">${number}</span>`;
  }
  return `
    <span class="page-kicker">${escapeHTML(page.kicker)}</span>
    <h3>${escapeHTML(page.title)}</h3>
    <p>${escapeHTML(page.text)}</p>
    <span class="page-number">${number}</span>
  `;
}

function renderPages() {
  const book = getCurrentBook();
  if (!book) return;
  const pages = book.pages || [];
  const leftPage = pages[currentPageIndex];
  const rightPage = pages[currentPageIndex + 1];
  document.getElementById("pageLeft").innerHTML = pageMarkup(leftPage, currentPageIndex + 1);
  document.getElementById("pageRight").innerHTML = pageMarkup(rightPage, currentPageIndex + 2);
  document.getElementById("pageTotal").textContent = pages.length;
  document.getElementById("pageCount").textContent = rightPage
    ? `${currentPageIndex + 1}—${currentPageIndex + 2}`
    : `${currentPageIndex + 1}`;
  updateReaderProgress();
}

function updateReaderProgress() {
  const book = getCurrentBook();
  if (!book) return;
  const total = book.pages.length;
  const current = Math.min(currentPageIndex + 2, total);
  document.getElementById("prevPage").disabled = currentPageIndex === 0;
  document.getElementById("nextPage").disabled = current >= total;
  document.getElementById("readerProgressBar").style.width = `${(current / total) * 100}%`;
  const fullIsVisible = !document.getElementById("fullText").classList.contains("hidden");
  document.getElementById("readerProgress").textContent = fullIsVisible
    ? `${current} из ${total} страниц`
    : "Краткое содержание";
}

function flipPage(direction) {
  const book = getCurrentBook();
  if (!book || isFlipping) return;
  const nextIndex = direction === "next" ? currentPageIndex + 2 : currentPageIndex - 2;
  if (nextIndex < 0 || nextIndex >= book.pages.length) return;

  const spread = document.getElementById("bookSpread");
  const pageTurn = document.getElementById("pageTurn");
  pageTurn.innerHTML = direction === "next"
    ? document.getElementById("pageRight").innerHTML
    : document.getElementById("pageLeft").innerHTML;
  pageTurn.className = `page-turn book-page ${direction}`;
  spread.classList.add("turning", direction);
  isFlipping = true;

  window.setTimeout(() => {
    currentPageIndex = nextIndex;
    renderPages();
    spread.classList.remove("turning", direction);
    pageTurn.className = "page-turn";
    pageTurn.innerHTML = "";
    isFlipping = false;
  }, 510);
}

document.querySelectorAll(".tab-btn").forEach((button) => {
  button.addEventListener("click", () => setReaderTab(button.dataset.tab));
});
document.getElementById("prevPage").addEventListener("click", () => flipPage("prev"));
document.getElementById("nextPage").addEventListener("click", () => flipPage("next"));

document.getElementById("bookmarkBtn").addEventListener("click", () => {
  const book = getCurrentBook();
  if (!book) return;
  bookmarks[currentBookId] = {
    title: book.title,
    page: currentPageIndex + 1,
    date: new Date().toLocaleString()
  };
  localStorage.setItem("bookmarks", JSON.stringify(bookmarks));
  document.getElementById("bookmarkBtn").textContent = "✓ Место сохранено";
  updateCounters();
});

// ===== КОРЗИНА =====
function addToCart(id) {
  const book = books.find((item) => item.id === id);
  if (!book) return;

  if (!cart.includes(id)) {
    cart.push(id);
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCounters();
  }

  if (!document.getElementById("cartDrawer").classList.contains("hidden")) {
    renderCart();
  }

  showToast(`«${book.title}» добавлена в корзину`);
}

function showToast(text) {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = text;
  document.body.appendChild(toast);

  window.setTimeout(() => toast.remove(), 2000);
}

function renderCart() {
  const list = document.getElementById("cartList");
  list.innerHTML = "";
  let total = 0;
  cart.forEach((id) => {
    const book = books.find((item) => item.id === id);
    if (!book) return;
    total += book.price;
    const item = document.createElement("div");
    item.className = "cart-item";
    item.innerHTML = `<span>${escapeHTML(book.title)}</span><span>${book.price} ₸ <button onclick="removeFromCart(${id})">Убрать</button></span>`;
    list.appendChild(item);
  });
  document.getElementById("cartTotal").textContent = cart.length ? "Итого: " + total + " ₸" : "Корзина пуста";
}

function removeFromCart(id) {
  cart = cart.filter((item) => item !== id);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
  updateCounters();
}

document.getElementById("checkoutBtn").addEventListener("click", () => {
  if (cart.length) alert("Оплата пока не подключена — это заглушка под будущую интеграцию.");
});

// ===== ЗАКЛАДКИ И ОКНА =====
function renderBookmarks() {
  const list = document.getElementById("bookmarksList");
  list.innerHTML = "";
  const entries = Object.entries(bookmarks);
  if (!entries.length) {
    list.innerHTML = "<p>Пока нет сохранённых мест.</p>";
    return;
  }
  entries.forEach(([id, data]) => {
    const item = document.createElement("div");
    item.className = "bookmark-item";
    item.innerHTML = `<span>${escapeHTML(data.title)}</span><span>стр. ${data.page || 1}</span>`;
    item.addEventListener("click", () => {
      hideModal("bookmarksModal");
      openReader(Number(id));
    });
    list.appendChild(item);
  });
}

function updateCounters() {
  document.getElementById("cartCount").textContent = cart.length;
  document.getElementById("bmCount").textContent = Object.keys(bookmarks).length;
}

function showModal(id) {
  document.getElementById(id).classList.remove("hidden");
}

function hideModal(id) {
  document.getElementById(id).classList.add("hidden");
}

document.getElementById("btnCart").addEventListener("click", () => {
  renderCart();
  showModal("cartDrawer");
});
document.getElementById("btnBookmarks").addEventListener("click", () => {
  renderBookmarks();
  showModal("bookmarksModal");
});
document.getElementById("btnAccount").addEventListener("click", () => showModal("accountModal"));

document.querySelectorAll("[data-close]").forEach((button) => {
  button.addEventListener("click", () => hideModal(button.dataset.close));
});

document.querySelectorAll(".modal").forEach((modal) => {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) hideModal(modal.id);
  });
});

document.addEventListener("keydown", (event) => {
  if (readerModal.classList.contains("hidden")) return;
  if (event.key === "Escape") hideModal("readerModal");
  if (event.key === "ArrowRight") flipPage("next");
  if (event.key === "ArrowLeft") flipPage("prev");
});

// ===== ЗАПУСК =====
renderBooks();
updateCounters();